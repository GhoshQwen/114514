import React from 'react';
import { Bot, Brain } from 'lucide-react';

const ModelSelector = ({ selectedModel, onModelChange }) => {
  const models = [
    {
      id: 'huatuo',
      name: '华佗GPT',
      description: '基于OpenAI的专业医疗咨询',
      icon: <Brain className="w-4 h-4" />,
    },
    {
      id: 'chatgpt',
      name: 'ChatGPT',
      description: '基于OpenAI的通用对话模型',
      icon: <Bot className="w-4 h-4" />,
    },
  ];

  return (
    <div className="flex items-center space-x-2">
      <span className="text-sm text-gray-600">选择模型:</span>
      <select
        value={selectedModel}
        onChange={(e) => onModelChange(e.target.value)}
        className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        {models.map((model) => (
          <option key={model.id} value={model.id}>
            {model.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default ModelSelector;
