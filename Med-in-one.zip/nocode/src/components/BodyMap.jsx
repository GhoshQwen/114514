import React from 'react';

const BodyMap = ({ selectedBodyPart, onBodyPartSelect }) => {
  const bodyParts = {
    male: {
      front: [
        { id: 'head', name: '头部', x: 50, y: 15, width: 20, height: 20 },
        { id: 'neck', name: '颈部', x: 50, y: 35, width: 10, height: 8 },
        { id: 'chest', name: '胸部', x: 50, y: 50, width: 30, height: 25 },
        { id: 'abdomen', name: '腹部', x: 50, y: 75, width: 25, height: 20 },
        { id: 'left-arm', name: '左臂', x: 20, y: 50, width: 15, height: 40 },
        { id: 'right-arm', name: '右臂', x: 80, y: 50, width: 15, height: 40 },
        { id: 'left-leg', name: '左腿', x: 40, y: 90, width: 15, height: 45 },
        { id: 'right-leg', name: '右腿', x: 60, y: 90, width: 15, height: 45 },
      ],
      back: [
        { id: 'back-head', name: '后脑', x: 50, y: 15, width: 20, height: 20 },
        { id: 'back-neck', name: '后颈', x: 50, y: 35, width: 10, height: 8 },
        { id: 'upper-back', name: '上背部', x: 50, y: 50, width: 30, height: 20 },
        { id: 'lower-back', name: '下背部', x: 50, y: 70, width: 25, height: 15 },
        { id: 'left-back-arm', name: '左后臂', x: 20, y: 50, width: 15, height: 40 },
        { id: 'right-back-arm', name: '右后臂', x: 80, y: 50, width: 15, height: 40 },
        { id: 'left-back-leg', name: '左后腿', x: 40, y: 90, width: 15, height: 45 },
        { id: 'right-back-leg', name: '右后腿', x: 60, y: 90, width: 15, height: 45 },
      ],
      side: [
        { id: 'side-head', name: '侧头部', x: 50, y: 15, width: 20, height: 20 },
        { id: 'side-neck', name: '侧颈部', x: 50, y: 35, width: 10, height: 8 },
        { id: 'side-chest', name: '侧胸部', x: 50, y: 50, width: 20, height: 25 },
        { id: 'side-abdomen', name: '侧腹部', x: 50, y: 75, width: 18, height: 20 },
        { id: 'side-arm', name: '侧臂', x: 75, y: 50, width: 10, height: 40 },
        { id: 'side-leg', name: '侧腿', x: 50, y: 90, width: 12, height: 45 },
      ],
    },
    female: {
      front: [
        { id: 'f-head', name: '头部', x: 50, y: 15, width: 20, height: 20 },
        { id: 'f-neck', name: '颈部', x: 50, y: 35, width: 10, height: 8 },
        { id: 'f-chest', name: '胸部', x: 50, y: 50, width: 30, height: 25 },
        { id: 'f-abdomen', name: '腹部', x: 50, y: 75, width: 25, height: 20 },
        { id: 'f-left-arm', name: '左臂', x: 20, y: 50, width: 15, height: 40 },
        { id: 'f-right-arm', name: '右臂', x: 80, y: 50, width: 15, height: 40 },
        { id: 'f-left-leg', name: '左腿', x: 40, y: 90, width: 15, height: 45 },
        { id: 'f-right-leg', name: '右腿', x: 60, y: 90, width: 15, height: 45 },
      ],
      back: [
        { id: 'f-back-head', name: '后脑', x: 50, y: 15, width: 20, height: 20 },
        { id: 'f-back-neck', name: '后颈', x: 50, y: 35, width: 10, height: 8 },
        { id: 'f-upper-back', name: '上背部', x: 50, y: 50, width: 30, height: 20 },
        { id: 'f-lower-back', name: '下背部', x: 50, y: 70, width: 25, height: 15 },
        { id: 'f-left-back-arm', name: '左后臂', x: 20, y: 50, width: 15, height: 40 },
        { id: 'f-right-back-arm', name: '右后臂', x: 80, y: 50, width: 15, height: 40 },
        { id: 'f-left-back-leg', name: '左后腿', x: 40, y: 90, width: 15, height: 45 },
        { id: 'f-right-back-leg', name: '右后腿', x: 60, y: 90, width: 15, height: 45 },
      ],
      side: [
        { id: 'f-side-head', name: '侧头部', x: 50, y: 15, width: 20, height: 20 },
        { id: 'f-side-neck', name: '侧颈部', x: 50, y: 35, width: 10, height: 8 },
        { id: 'f-side-chest', name: '侧胸部', x: 50, y: 50, width: 20, height: 25 },
        { id: 'f-side-abdomen', name: '侧腹部', x: 50, y: 75, width: 18, height: 20 },
        { id: 'f-side-arm', name: '侧臂', x: 75, y: 50, width: 10, height: 40 },
        { id: 'f-side-leg', name: '侧腿', x: 50, y: 90, width: 12, height: 45 },
      ],
    },
  };

  const [gender, setGender] = React.useState('male');
  const [view, setView] = React.useState('front');

  const currentParts = bodyParts[gender][view];

  return (
    <div className="space-y-4">
      <div className="flex space-x-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            性别
          </label>
          <select
            value={gender}
            onChange={(e) => setGender(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="male">男性</option>
            <option value="female">女性</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            视图
          </label>
          <select
            value={view}
            onChange={(e) => setView(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="front">正面</option>
            <option value="back">背面</option>
            <option value="side">侧面</option>
          </select>
        </div>
      </div>

      <div className="relative bg-gray-100 rounded-lg p-4" style={{ height: '400px' }}>
        <svg width="100%" height="100%" viewBox="0 0 100 120">
          {currentParts.map((part) => (
            <g key={part.id}>
              <rect
                x={part.x - part.width / 2}
                y={part.y - part.height / 2}
                width={part.width}
                height={part.height}
                fill={selectedBodyPart?.id === part.id ? '#3B82F6' : '#E5E7EB'}
                stroke="#9CA3AF"
                strokeWidth="0.5"
                className="cursor-pointer hover:fill-blue-300 transition-colors"
                onClick={() => onBodyPartSelect(part)}
              />
              <text
                x={part.x}
                y={part.y + part.height / 2 + 4}
                textAnchor="middle"
                className="text-xs fill-gray-600 pointer-events-none"
              >
                {part.name}
              </text>
            </g>
          ))}
        </svg>
      </div>
    </div>
  );
};

export default BodyMap;
