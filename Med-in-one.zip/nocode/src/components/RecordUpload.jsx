import React, { useState } from 'react';
import { X, Upload, FileText, Image, Wand2, Scan } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { addMedicalRecord } from '../utils/medicalRecordUtils';
import { recognizeImageWithBaiduOCR } from '../utils/ocrService';

const RecordUpload = ({ onClose, onSuccess }) => {
  const [title, setTitle] = useState('');
  const [summary, setSummary] = useState('');
  const [content, setContent] = useState('');
  const [files, setFiles] = useState([]);
  const [uploadType, setUploadType] = useState('text');
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [isRecognizing, setIsRecognizing] = useState(false);

  const uploadMutation = useMutation({
    mutationFn: addMedicalRecord,
    onSuccess: () => {
      onSuccess();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim() || (!content.trim() && files.length === 0)) {
      alert('请填写完整信息');
      return;
    }

    uploadMutation.mutate({
      title,
      content: summary || content, // 使用生成的摘要或原始内容
      files,
      type: 'uploaded',
      originalContent: content, // 保存原始内容
    });
  };

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles(selectedFiles);
  };

  const handleGenerateSummary = async () => {
    if (!content.trim()) {
      alert('请先输入病历内容');
      return;
    }

    setIsGeneratingSummary(true);
    try {
      // 使用ChatGPT API生成摘要和标题
      const response = await fetch('https://api.chatanywhere.tech/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer sk-zBeMNF8UmOLDmq76SxjNskOFQRwbONmUueYuMITpvcMBauX7'
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [{
            role: "user",
            content: `请为以下病历内容生成一个简短的标题和摘要。标题应该简洁明了，摘要应该包含关键信息，字数控制在100字以内。

内容：${content}

请按照以下格式返回：
标题：[生成的标题]
摘要：[生成的摘要]`
          }],
          temperature: 0.7,
          max_tokens: 300,
          stream: false
        }),
      });

      if (!response.ok) {
        throw new Error('生成摘要失败');
      }

      const data = await response.json();
      const result = data.choices[0].message.content;
      
      // 解析返回的标题和摘要
      const titleMatch = result.match(/标题[:：]\s*(.+)/);
      const summaryMatch = result.match(/摘要[:：]\s*(.+)/);
      
      if (titleMatch) {
        setTitle(titleMatch[1].trim());
      }
      
      if (summaryMatch) {
        setSummary(summaryMatch[1].trim());
      }
    } catch (error) {
      console.error('生成摘要失败:', error);
      alert('生成摘要失败，请稍后重试');
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  const handleImageRecognition = async () => {
    if (files.length === 0) {
      alert('请先选择图片文件');
      return;
    }

    // 检查是否为图片文件
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    if (imageFiles.length === 0) {
      alert('请选择图片文件进行识别');
      return;
    }

    setIsRecognizing(true);
    try {
      // 对每个图片文件进行OCR识别
      const recognitionResults = await Promise.all(
        imageFiles.map(async (file) => {
          const result = await recognizeImageWithBaiduOCR(file);
          return result;
        })
      );

      // 合并所有识别结果
      const successfulResults = recognitionResults.filter(result => result.success);
      if (successfulResults.length > 0) {
        const combinedText = successfulResults
          .map(result => result.text)
          .join('\n\n');
        
        setContent(combinedText);
        
        // 自动生成标题和摘要
        const response = await fetch('https://api.chatanywhere.tech/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer sk-zBeMNF8UmOLDmq76SxjNskOFQRwbONmUueYuMITpvcMBauX7'
          },
          body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [{
              role: "user",
              content: `请为以下OCR识别的病历内容生成一个简短的标题和摘要。标题应该简洁明了，摘要应该包含关键信息，字数控制在100字以内。

内容：${combinedText}

请按照以下格式返回：
标题：[生成的标题]
摘要：[生成的摘要]`
            }],
            temperature: 0.7,
            max_tokens: 300,
            stream: false
          }),
        });

        if (response.ok) {
          const data = await response.json();
          const result = data.choices[0].message.content;
          
          // 解析返回的标题和摘要
          const titleMatch = result.match(/标题[:：]\s*(.+)/);
          const summaryMatch = result.match(/摘要[:：]\s*(.+)/);
          
          if (titleMatch) {
            setTitle(titleMatch[1].trim());
          }
          
          if (summaryMatch) {
            setSummary(summaryMatch[1].trim());
          }
        }
      } else {
        const errorMessages = recognitionResults
          .filter(result => !result.success)
          .map(result => result.error)
          .join('\n');
        alert(`图片识别失败：\n${errorMessages}`);
      }
    } catch (error) {
      console.error('图片识别失败:', error);
      alert('图片识别失败，请稍后重试');
    } finally {
      setIsRecognizing(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-800">上传病历</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              记录标题
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="请输入记录标题"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              上传类型
            </label>
            <div className="flex space-x-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="text"
                  checked={uploadType === 'text'}
                  onChange={(e) => setUploadType(e.target.value)}
                  className="mr-2"
                />
                <FileText className="w-4 h-4 mr-1" />
                文本
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="file"
                  checked={uploadType === 'file'}
                  onChange={(e) => setUploadType(e.target.value)}
                  className="mr-2"
                />
                <Image className="w-4 h-4 mr-1" />
                文件
              </label>
            </div>
          </div>

          {uploadType === 'text' ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  病历内容
                </label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="请输入病历内容..."
                />
              </div>
              
              {content.trim() && (
                <div>
                  <button
                    type="button"
                    onClick={handleGenerateSummary}
                    disabled={isGeneratingSummary}
                    className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
                  >
                    <Wand2 className="w-4 h-4 mr-2" />
                    {isGeneratingSummary ? '生成中...' : '智能概括'}
                  </button>
                </div>
              )}
              
              {summary && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    内容摘要
                  </label>
                  <textarea
                    value={summary}
                    onChange={(e) => setSummary(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="内容摘要..."
                  />
                </div>
              )}
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                上传文件
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                <input
                  type="file"
                  multiple
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                  accept=".txt,.pdf,.jpg,.jpeg,.png"
                />
                <label
                  htmlFor="file-upload"
                  className="cursor-pointer flex flex-col items-center"
                >
                  <Upload className="w-8 h-8 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-600">
                    点击选择文件或拖拽文件到此处
                  </span>
                </label>
                {files.length > 0 && (
                  <div className="mt-2 text-sm text-gray-600">
                    已选择 {files.length} 个文件
                  </div>
                )}
              </div>
              
              {files.length > 0 && (
                <div className="mt-4">
                  <button
                    type="button"
                    onClick={handleImageRecognition}
                    disabled={isRecognizing}
                    className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                  >
                    <Scan className="w-4 h-4 mr-2" />
                    {isRecognizing ? '识别中...' : '图片识别'}
                  </button>
                </div>
              )}
            </div>
          )}

          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
            >
              取消
            </button>
            <button
              type="submit"
              disabled={uploadMutation.isPending}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {uploadMutation.isPending ? '上传中...' : '上传'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RecordUpload;
