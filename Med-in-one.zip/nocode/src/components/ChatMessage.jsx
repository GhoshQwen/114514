import React from 'react';
import { User, Bot, AlertCircle, Brain, Image, Heart } from 'lucide-react';

const ChatMessage = ({ message }) => {
  const isUser = message.sender === 'user';
  const isError = message.isError;
  const isReminder = message.isReminder;

  const getModelIcon = (model) => {
    switch (model) {
      case 'huatuo':
        return <Brain className="w-4 h-4" />;
      case 'system':
        return <Heart className="w-4 h-4" />;
      default:
        return <Bot className="w-4 h-4" />;
    }
  };

  const getModelName = (model) => {
    switch (model) {
      case 'huatuo':
        return 'ChatGPT';
      case 'system':
        return '系统提醒';
      default:
        return '华佗gpt';
    }
  };

  // 安全地检查消息内容是否包含图片识别结果
  const messageContent = message.content || '';
  const hasImageRecognition = typeof messageContent === 'string' && messageContent.includes('[图片识别结果]');

  return (
    <div className={`flex mb-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex max-w-xs lg:max-w-md ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={`flex-shrink-0 ${isUser ? 'ml-3' : 'mr-3'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
            isUser ? 'bg-blue-500' : isError ? 'bg-red-500' : isReminder ? 'bg-pink-500' : 'bg-gray-500'
          }`}>
            {isUser ? (
              <User className="w-4 h-4 text-white" />
            ) : isError ? (
              <AlertCircle className="w-4 h-4 text-white" />
            ) : (
              getModelIcon(message.model)
            )}
          </div>
        </div>
        <div className={`px-4 py-2 rounded-lg ${
          isUser 
            ? 'bg-blue-500 text-white' 
            : isError 
            ? 'bg-red-100 text-red-800 border border-red-300'
            : isReminder
            ? 'bg-pink-50 text-pink-800 border border-pink-200'
            : 'bg-gray-100 text-gray-800'
        }`}>
          {hasImageRecognition ? (
            <div className="space-y-2">
              <div className="flex items-center text-sm text-gray-500">
                <Image className="w-4 h-4 mr-1" />
                <span>图片识别结果</span>
              </div>
              <div className="whitespace-pre-wrap">{messageContent.replace('[图片识别结果]:\n', '')}</div>
            </div>
          ) : (
            <p className="text-sm whitespace-pre-wrap">{messageContent}</p>
          )}
          {!isUser && !isError && !isReminder && (
            <div className="mt-2 text-xs text-gray-500">
              <p className="text-red-500">* 以上建议仅供参考，请咨询专业医生</p>
            </div>
          )}
          {isReminder && (
            <div className="mt-2 text-xs text-pink-600">
              <p>💡 心理健康提醒</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
