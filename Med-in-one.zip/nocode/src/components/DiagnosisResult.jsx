import React from 'react';
import { AlertTriangle, Pill, Activity, Utensils, Brain, Bot } from 'lucide-react';

const DiagnosisResult = ({ result }) => {
  if (!result) return null;

  const getModelIcon = (model) => {
    switch (model) {
      case 'huatuo':
        return <Brain className="w-5 h-5" />;
      default:
        return <Bot className="w-5 h-5" />;
    }
  };

  const getModelName = (model) => {
    switch (model) {
      case 'huatuo':
        return 'ChatGPT';
      default:
        return '华佗gpt';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <AlertTriangle className="w-6 h-6 text-orange-500 mr-3" />
        <h2 className="text-2xl font-bold text-gray-800">诊断结果</h2>
      </div>

      <div className="space-y-6">
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="font-semibold text-blue-800 mb-2">可能病症</h3>
          <p className="text-blue-700">{result.possibleConditions}</p>
        </div>

        <div className="bg-green-50 p-4 rounded-lg">
          <h3 className="font-semibold text-green-800 mb-2">发病原因</h3>
          <p className="text-green-700">{result.causes}</p>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-purple-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <Pill className="w-5 h-5 text-purple-600 mr-2" />
              <h3 className="font-semibold text-purple-800">药物建议</h3>
            </div>
            <p className="text-purple-700 text-sm">{result.medicationAdvice}</p>
          </div>

          <div className="bg-orange-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <Activity className="w-5 h-5 text-orange-600 mr-2" />
              <h3 className="font-semibold text-orange-800">运动建议</h3>
            </div>
            <p className="text-orange-700 text-sm">{result.exerciseAdvice}</p>
          </div>

          <div className="bg-red-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <Utensils className="w-5 h-5 text-red-600 mr-2" />
              <h3 className="font-semibold text-red-800">饮食建议</h3>
            </div>
            <p className="text-red-700 text-sm">{result.dietAdvice}</p>
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
          <div className="flex items-start">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mr-2 mt-0.5" />
            <div>
              <h3 className="font-semibold text-yellow-800 mb-1">免责声明</h3>
              <p className="text-yellow-700 text-sm">
                以上诊断结果仅供参考，不能替代专业医生的诊断。如有严重症状，请及时就医。
              </p>
            </div>
          </div>
        </div>

        <div className="text-sm text-gray-500">
          <p>诊断时间: {new Date().toLocaleString()}</p>
          <div className="flex items-center">
            <span>诊断模型: </span>
            <span className="flex items-center ml-1">
              {getModelIcon(result.model)}
              <span className="ml-1">{getModelName(result.model)}</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiagnosisResult;
