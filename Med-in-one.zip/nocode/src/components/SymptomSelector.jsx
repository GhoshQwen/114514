import React from 'react';
import { Check } from 'lucide-react';

const SymptomSelector = ({ bodyPart, selectedSymptoms, onSymptomSelect }) => {
  const commonSymptoms = [
    { id: 'pain', name: '疼痛', color: 'text-red-600' },
    { id: 'redness', name: '发红', color: 'text-red-500' },
    { id: 'swelling', name: '肿胀', color: 'text-orange-500' },
    { id: 'itching', name: '瘙痒', color: 'text-green-500' },
    { id: 'numbness', name: '麻木', color: 'text-blue-500' },
    { id: 'tingling', name: '刺痛', color: 'text-purple-500' },
    { id: 'weakness', name: '无力', color: 'text-gray-500' },
    { id: 'stiffness', name: '僵硬', color: 'text-gray-600' },
  ];

  const handleSymptomToggle = (symptom) => {
    const isSelected = selectedSymptoms.some(s => s.id === symptom.id);
    if (isSelected) {
      onSymptomSelect(selectedSymptoms.filter(s => s.id !== symptom.id));
    } else {
      onSymptomSelect([...selectedSymptoms, symptom]);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 p-4 rounded-lg">
        <h3 className="font-medium text-blue-800 mb-2">已选择部位</h3>
        <p className="text-blue-600">{bodyPart.name}</p>
      </div>

      <div>
        <h3 className="font-medium text-gray-800 mb-3">选择症状</h3>
        <div className="grid grid-cols-2 gap-3">
          {commonSymptoms.map((symptom) => {
            const isSelected = selectedSymptoms.some(s => s.id === symptom.id);
            return (
              <button
                key={symptom.id}
                onClick={() => handleSymptomToggle(symptom)}
                className={`p-3 rounded-lg border-2 transition-all ${
                  isSelected
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-gray-200 hover:border-gray-300 text-gray-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`font-medium ${symptom.color}`}>
                    {symptom.name}
                  </span>
                  {isSelected && (
                    <Check className="w-4 h-4 text-blue-600" />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {selectedSymptoms.length > 0 && (
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-medium text-gray-800 mb-2">已选择症状</h3>
          <div className="flex flex-wrap gap-2">
            {selectedSymptoms.map((symptom) => (
              <span
                key={symptom.id}
                className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
              >
                {symptom.name}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SymptomSelector;
