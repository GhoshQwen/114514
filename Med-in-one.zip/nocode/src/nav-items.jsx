import { HomeIcon, Stethoscope, FileText, MapPin } from "lucide-react";
import Index from "./pages/Index.jsx";
import ConsultationPage from "./pages/ConsultationPage.jsx";
import MedicalRecordPage from "./pages/MedicalRecordPage.jsx";
import BodyMapPage from "./pages/BodyMapPage.jsx";

/**
 * Central place for defining the navigation items. Used for navigation components and routing.
 */
export const navItems = [
  {
    title: "首页",
    to: "/",
    icon: <HomeIcon className="h-4 w-4" />,
    page: <Index />,
  },
  {
    title: "智能问诊",
    to: "/consultation",
    icon: <Stethoscope className="h-4 w-4" />,
    page: <ConsultationPage />,
  },
  {
    title: "病历管理",
    to: "/medical-record",
    icon: <FileText className="h-4 w-4" />,
    page: <MedicalRecordPage />,
  },
  {
    title: "人体图诊断",
    to: "/body-map",
    icon: <MapPin className="h-4 w-4" />,
    page: <BodyMapPage />,
  },
];
