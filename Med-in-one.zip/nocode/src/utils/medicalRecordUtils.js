// 模拟本地存储的病历数据
const STORAGE_KEY = 'medicalRecords';

// 获取所有病历记录
export const getMedicalRecords = async () => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('获取病历记录失败:', error);
    return [];
  }
};

// 添加病历记录
export const addMedicalRecord = async (record) => {
  try {
    const records = await getMedicalRecords();
    const newRecord = {
      id: Date.now().toString(),
      title: record.title || '问诊记录',
      content: record.content || '',
      originalContent: record.originalContent || '', // 保存原始内容
      files: record.files || [],
      type: record.type || 'consultation',
      timestamp: new Date().toISOString(),
    };
    
    const updatedRecords = [...records, newRecord];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedRecords));
    return newRecord;
  } catch (error) {
    console.error('添加病历记录失败:', error);
    throw error;
  }
};

// 删除病历记录
export const deleteMedicalRecord = async (recordId) => {
  try {
    const records = await getMedicalRecords();
    const updatedRecords = records.filter(record => record.id !== recordId);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedRecords));
    return true;
  } catch (error) {
    console.error('删除病历记录失败:', error);
    throw error;
  }
};

// 更新病历记录
export const updateMedicalRecord = async (recordId, updates) => {
  try {
    const records = await getMedicalRecords();
    const updatedRecords = records.map(record =>
      record.id === recordId ? { ...record, ...updates } : record
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedRecords));
    return true;
  } catch (error) {
    console.error('更新病历记录失败:', error);
    throw error;
  }
};

// 将文件转换为base64
export const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      // 移除data URL前缀，只保留base64数据
      const base64String = reader.result.split(',')[1];
      resolve(base64String);
    };
    reader.onerror = (error) => reject(error);
  });
};

// 将base64转换为Blob
export const base64ToBlob = (base64, mimeType) => {
  const byteCharacters = atob(base64);
  const byteArrays = [];
  
  for (let offset = 0; offset < byteCharacters.length; offset += 512) {
    const slice = byteCharacters.slice(offset, offset + 512);
    
    const byteNumbers = new Array(slice.length);
    for (let i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }
    
    const byteArray = new Uint8Array(byteNumbers);
    byteArrays.push(byteArray);
  }
  
  return new Blob(byteArrays, { type: mimeType });
};
