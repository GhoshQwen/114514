import axios from 'axios';

// 百度OCR API配置
const BAIDU_OCR_CONFIG = {
  tokenUrl: 'https://aip.baidubce.com/oauth/2.0/token',
  ocrUrl: 'https://aip.baidubce.com/rest/2.0/ocr/v1/general'
};

// 获取百度OCR访问令牌
export const getBaiduAccessToken = async () => {
  try {
    const response = await axios.get(BAIDU_OCR_CONFIG.tokenUrl, {
      params: {
        grant_type: 'client_credentials',
        client_id: 'mM15YalANSW19Xr3yqjcmpLj',
        client_secret: 'oInKSo7gSJOq4e1GZ7GZS8KOL5rnlmf0'
      }
    });
    
    return response.data.access_token;
  } catch (error) {
    console.error('获取百度OCR访问令牌失败:', error);
    throw new Error('获取OCR服务认证失败');
  }
};

// 使用百度OCR识别图片
export const recognizeImageWithBaiduOCR = async (imageFile) => {
  try {
    // 获取访问令牌
    const accessToken = '24.83e0a880ddfd023bb13dea670b4e529e.2592000.1764002707.282335-120513666';
    
    // 将图片转换为base64
    const base64Image = await fileToBase64(imageFile);
    
    // 调用百度OCR API
    const response = await axios.post(
      `${BAIDU_OCR_CONFIG.ocrUrl}?access_token=${accessToken}`,
      new URLSearchParams({
        image: base64Image,
        probability: 'true'
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );
    
    // 处理识别结果
    if (response.data.words_result && response.data.words_result.length > 0) {
      const recognizedText = response.data.words_result
        .map(item => item.words)
        .join('\n');
      
      return {
        success: true,
        text: recognizedText,
        confidence: response.data.words_result[0]?.probability?.average || 0
      };
    } else {
      throw new Error('未识别到文字');
    }
  } catch (error) {
    console.error('OCR识别失败:', error);
    return {
      success: false,
      error: error.message || '识别失败'
    };
  }
};

// 将文件转换为base64
const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      // 移除data URL前缀，只保留base64数据
      const base64String = reader.result.split(',')[1];
      resolve(base64String);
    };
    reader.onerror = (error) => reject(error);
  });
};
