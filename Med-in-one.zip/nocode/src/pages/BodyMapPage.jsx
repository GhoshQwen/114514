import { useNavigate } from 'react-router-dom';
import DiagnosisResult from '../components/DiagnosisResult';
import { Utensils, AlertCircle, MapPin, ChevronRight, ArrowLeft } from 'lucide-react';
import SymptomSelector from '../components/SymptomSelector';
import React, { useState } from 'react';
import BodyMap from '../components/BodyMap';

const BodyMapPage = () => {
  const navigate = useNavigate();
  const [selectedBodyPart, setSelectedBodyPart] = useState(null);
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [diagnosisResult, setDiagnosisResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeMode, setActiveMode] = useState('diagnosis'); // 'diagnosis' or 'diet'
  const [dietAnswers, setDietAnswers] = useState({});
  const [dietPlan, setDietPlan] = useState(null);
  const [isGeneratingDiet, setIsGeneratingDiet] = useState(false);

  const handleBodyPartSelect = (bodyPart) => {
    setSelectedBodyPart(bodyPart);
    setSelectedSymptoms([]);
    setDiagnosisResult(null);
  };

  const handleSymptomSelect = (symptoms) => {
    setSelectedSymptoms(symptoms);
  };

  const handleDiagnosis = async () => {
    if (!selectedBodyPart || selectedSymptoms.length === 0) {
      alert('请选择身体部位和症状');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/body-diagnosis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bodyPart: selectedBodyPart,
          symptoms: selectedSymptoms,
        }),
      });

      if (!response.ok) {
        throw new Error('诊断请求失败');
      }

      const data = await response.json();
      setDiagnosisResult(data);
    } catch (error) {
      console.error('诊断失败:', error);
      alert('诊断服务暂时不可用，请稍后重试');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDietPlan = () => {
    setActiveMode('diet');
  };

  const handleBackToDiagnosis = () => {
    setActiveMode('diagnosis');
  };

  const handleStartDiagnosis = () => {
    if (!selectedBodyPart || selectedSymptoms.length === 0) {
      alert('请选择身体部位和症状');
      return;
    }
    
    // 将部位和症状组合成输入内容
    const bodyPartName = selectedBodyPart.name;
    const symptomsText = selectedSymptoms.map(s => s.name).join('、');
    const inputText = `${bodyPartName}出现${symptomsText}`;
    
    // 跳转到智能问诊页面并传递输入内容
    navigate('/consultation', { state: { inputText } });
  };

  const handleDietAnswerChange = (questionId, answer) => {
    setDietAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleGenerateDietPlan = async () => {
    // 收集所有答案
    const answers = Object.entries(dietAnswers).map(([question, answer]) => {
      return `${question}: ${Array.isArray(answer) ? answer.join(', ') : answer}`;
    }).join('\n');

    if (!answers.trim()) {
      alert('请至少回答一个问题');
      return;
    }

    setIsGeneratingDiet(true);
    try {
      // 调用ChatGPT API生成糖尿病食谱
      const response = await fetch('https://api.chatanywhere.tech/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer sk-zBeMNF8UmOLDmq76SxjNskOFQRwbONmUueYuMITpvcMBauX7'
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [{
            role: "user",
            content: `基于以下糖尿病患者的饮食偏好和需求，请生成一份个性化的糖尿病食谱。

患者饮食偏好和需求：
${answers}

请生成一份详细的糖尿病食谱，包括：
1. 早餐、午餐、晚餐和加餐的具体食物建议
2. 每餐的食材搭配和烹饪方法
3. 食物的分量建议
4. 需要避免的食物
5. 饮食注意事项

请用中文回答，并确保食谱符合糖尿病饮食管理原则。`
          }],
          temperature: 0.7,
          max_tokens: 2000,
          stream: false
        }),
      });

      if (!response.ok) {
        throw new Error('生成食谱失败');
      }

      const data = await response.json();
      const result = data.choices[0].message.content;
      setDietPlan(result);
    } catch (error) {
      console.error('生成食谱失败:', error);
      alert('生成食谱失败，请稍后重试');
    } finally {
      setIsGeneratingDiet(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <button
              onClick={() => navigate('/')}
              className="flex items-center text-gray-600 hover:text-gray-800 mr-4"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              返回首页
            </button>
            <h1 className="text-2xl font-bold text-gray-800">人体部位诊断</h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {activeMode === 'diagnosis' ? (
            <>
              <div className="grid lg:grid-cols-2 gap-8">
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">
                    选择身体部位
                  </h2>
                  <BodyMap
                    selectedBodyPart={selectedBodyPart}
                    onBodyPartSelect={handleBodyPartSelect}
                  />
                </div>

                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">
                    症状选择
                  </h2>
                  {selectedBodyPart ? (
                    <SymptomSelector
                      bodyPart={selectedBodyPart}
                      selectedSymptoms={selectedSymptoms}
                      onSymptomSelect={handleSymptomSelect}
                    />
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <MapPin className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <p>请先选择身体部位</p>
                    </div>
                  )}

                  {selectedBodyPart && selectedSymptoms.length > 0 && (
                    <div className="mt-6 space-y-3">
                      <button
                        onClick={handleStartDiagnosis}
                        disabled={isLoading}
                        className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                      >
                        开始诊断
                        <ChevronRight className="w-5 h-5 ml-2" />
                      </button>
                      <button
                        onClick={handleDietPlan}
                        className="w-full px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center justify-center"
                      >
                        <Utensils className="w-5 h-5 mr-2" />
                        糖尿病食谱
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {diagnosisResult && (
                <div className="mt-8">
                  <DiagnosisResult result={diagnosisResult} />
                </div>
              )}
            </>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-800">糖尿病食谱</h2>
                <button
                  onClick={handleBackToDiagnosis}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                >
                  返回诊断
                </button>
              </div>
              
              {!dietPlan ? (
                <div className="space-y-6">
                  <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                    <h3 className="font-semibold text-yellow-800 mb-2">饮食倾向测试</h3>
                    <p className="text-yellow-700 text-sm">
                      请回答以下问题，我们将根据您的饮食习惯为您推荐适合的糖尿病食谱。
                    </p>
                  </div>
                  
                  <div className="space-y-6">
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-800 mb-3">饮食习惯偏好</h4>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您偏好的主食类型（可多选）</p>
                          <div className="grid grid-cols-2 gap-2">
                            {['米饭', '面食', '粗粮（燕麦、藜麦等）', '薯类（红薯、山药等）', '其他'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="checkbox" 
                                  className="mr-2" 
                                  checked={dietAnswers['主食偏好']?.includes(item) || false}
                                  onChange={(e) => {
                                    const currentAnswers = dietAnswers['主食偏好'] || [];
                                    if (e.target.checked) {
                                      handleDietAnswerChange('主食偏好', [...currentAnswers, item]);
                                    } else {
                                      handleDietAnswerChange('主食偏好', currentAnswers.filter(a => a !== item));
                                    }
                                  }}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您对豆制品的接受程度</p>
                          <div className="space-y-2">
                            {['经常食用', '偶尔食用', '很少食用', '完全不食用'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="radio" 
                                  name="tofu" 
                                  className="mr-2" 
                                  checked={dietAnswers['豆制品接受度'] === item}
                                  onChange={() => handleDietAnswerChange('豆制品接受度', item)}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-800 mb-3">蛋白质来源偏好</h4>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您偏好的肉类选择（可多选）</p>
                          <div className="grid grid-cols-2 gap-2">
                            {['鸡肉', '鸭肉', '鱼肉', '虾类', '牛肉', '猪肉', '其他'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="checkbox" 
                                  className="mr-2" 
                                  checked={dietAnswers['肉类偏好']?.includes(item) || false}
                                  onChange={(e) => {
                                    const currentAnswers = dietAnswers['肉类偏好'] || [];
                                    if (e.target.checked) {
                                      handleDietAnswerChange('肉类偏好', [...currentAnswers, item]);
                                    } else {
                                      handleDietAnswerChange('肉类偏好', currentAnswers.filter(a => a !== item));
                                    }
                                  }}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                          <label className="flex items-center mt-2">
                            <input 
                              type="checkbox" 
                              className="mr-2" 
                              checked={dietAnswers['素食主义'] === '是'}
                              onChange={(e) => handleDietAnswerChange('素食主义', e.target.checked ? '是' : '否')}
                            />
                            <span className="text-sm">我是素食主义者</span>
                          </label>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您偏好的烹饪方式（可多选）</p>
                          <div className="grid grid-cols-2 gap-2">
                            {['清蒸', '水煮', '快炒', '炖煮', '烤制', '凉拌'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="checkbox" 
                                  className="mr-2" 
                                  checked={dietAnswers['烹饪方式']?.includes(item) || false}
                                  onChange={(e) => {
                                    const currentAnswers = dietAnswers['烹饪方式'] || [];
                                    if (e.target.checked) {
                                      handleDietAnswerChange('烹饪方式', [...currentAnswers, item]);
                                    } else {
                                      handleDietAnswerChange('烹饪方式', currentAnswers.filter(a => a !== item));
                                    }
                                  }}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-800 mb-3">蔬菜水果偏好</h4>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您经常食用的蔬菜类型（可多选）</p>
                          <div className="grid grid-cols-2 gap-2">
                            {['叶菜类（菠菜、生菜等）', '根茎类（胡萝卜、白萝卜等）', '瓜果类（黄瓜、西红柿等）', '菌菇类（香菇、金针菇等）', '豆类（豌豆、豆角等）'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="checkbox" 
                                  className="mr-2" 
                                  checked={dietAnswers['蔬菜偏好']?.includes(item) || false}
                                  onChange={(e) => {
                                    const currentAnswers = dietAnswers['蔬菜偏好'] || [];
                                    if (e.target.checked) {
                                      handleDietAnswerChange('蔬菜偏好', [...currentAnswers, item]);
                                    } else {
                                      handleDietAnswerChange('蔬菜偏好', currentAnswers.filter(a => a !== item));
                                    }
                                  }}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您对水果的食用习惯</p>
                          <div className="space-y-2">
                            {['每天食用', '每周3-4次', '偶尔食用', '基本不食用'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="radio" 
                                  name="fruit" 
                                  className="mr-2" 
                                  checked={dietAnswers['水果食用习惯'] === item}
                                  onChange={() => handleDietAnswerChange('水果食用习惯', item)}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-800 mb-3">饮食习惯</h4>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您的用餐频率</p>
                          <div className="space-y-2">
                            {['一日三餐', '少食多餐（5-6次/天）', '不规律'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="radio" 
                                  name="meal-frequency" 
                                  className="mr-2" 
                                  checked={dietAnswers['用餐频率'] === item}
                                  onChange={() => handleDietAnswerChange('用餐频率', item)}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您的口味偏好</p>
                          <div className="space-y-2">
                            {['清淡', '适中', '偏咸', '偏甜（需特别注意）', '偏辣'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="radio" 
                                  name="taste" 
                                  className="mr-2" 
                                  checked={dietAnswers['口味偏好'] === item}
                                  onChange={() => handleDietAnswerChange('口味偏好', item)}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-800 mb-3">特殊情况</h4>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您是否有其他饮食限制或过敏？</p>
                          <div className="grid grid-cols-2 gap-2">
                            {['乳糖不耐受', '海鲜过敏', '坚果过敏', '麸质过敏', '无', '其他'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="checkbox" 
                                  className="mr-2" 
                                  checked={dietAnswers['饮食限制']?.includes(item) || false}
                                  onChange={(e) => {
                                    const currentAnswers = dietAnswers['饮食限制'] || [];
                                    if (e.target.checked) {
                                      handleDietAnswerChange('饮食限制', [...currentAnswers, item]);
                                    } else {
                                      handleDietAnswerChange('饮食限制', currentAnswers.filter(a => a !== item));
                                    }
                                  }}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-600 mb-2">您的血糖控制目标</p>
                          <div className="space-y-2">
                            {['严格控制', '一般控制', '维持现状'].map((item) => (
                              <label key={item} className="flex items-center">
                                <input 
                                  type="radio" 
                                  name="blood-sugar" 
                                  className="mr-2" 
                                  checked={dietAnswers['血糖控制目标'] === item}
                                  onChange={() => handleDietAnswerChange('血糖控制目标', item)}
                                />
                                <span className="text-sm">{item}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-800 mb-3">补充说明</h4>
                      <div>
                        <p className="text-sm text-gray-600 mb-2">其他需要说明的情况（选填）</p>
                        <textarea 
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                          rows="3" 
                          placeholder="请在此填写任何其他饮食需求、偏好或特殊情况..."
                          value={dietAnswers['补充说明'] || ''}
                          onChange={(e) => handleDietAnswerChange('补充说明', e.target.value)}
                        ></textarea>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <button 
                      className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                      onClick={handleGenerateDietPlan}
                      disabled={isGeneratingDiet}
                    >
                      {isGeneratingDiet ? '生成中...' : '生成糖尿病食谱'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                    <h3 className="font-semibold text-green-800 mb-2">个性化糖尿病食谱</h3>
                    <div className="prose max-w-none">
                      <pre className="whitespace-pre-wrap text-sm text-green-700">{dietPlan}</pre>
                    </div>
                  </div>
                  
                  <div className="flex justify-center space-x-4">
                    <button 
                      className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      onClick={() => setDietPlan(null)}
                    >
                      重新生成
                    </button>
                    <button 
                      className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                      onClick={handleBackToDiagnosis}
                    >
                      返回诊断
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BodyMapPage;
