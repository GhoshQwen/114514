import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getMedicalRecords, addMedicalRecord, deleteMedicalRecord } from '../utils/medicalRecordUtils';
import { recognizeImageWithBaiduOCR } from '../utils/ocrService';
import { Eye, Trash2, Scan, X, ZoomIn, Upload, Plus, FileText, Image, ArrowLeft } from 'lucide-react';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import RecordUpload from '../components/RecordUpload';
const MedicalRecordPage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('history');
  const [showUpload, setShowUpload] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [showImageDialog, setShowImageDialog] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [isRecognizing, setIsRecognizing] = useState(false);
  const queryClient = useQueryClient();

  const { data: records, isLoading } = useQuery({
    queryKey: ['medicalRecords'],
    queryFn: getMedicalRecords,
  });

  const deleteMutation = useMutation({
    mutationFn: deleteMedicalRecord,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['medicalRecords'] });
    },
  });

  const handleDeleteRecord = (recordId) => {
    if (window.confirm('确定要删除这条记录吗？')) {
      deleteMutation.mutate(recordId);
    }
  };

  const handleViewDetail = (record) => {
    setSelectedRecord(record);
    setShowDetailDialog(true);
  };

  const handleViewImage = (imageUrl) => {
    setSelectedImage(imageUrl);
    setShowImageDialog(true);
  };

  const handleImageRecognition = async (record) => {
    if (!record.files || record.files.length === 0) {
      alert('该记录没有可识别的图片文件');
      return;
    }

    // 检查是否为图片文件
    const imageFiles = record.files.filter(file => file.type && file.type.startsWith('image/'));
    if (imageFiles.length === 0) {
      alert('该记录没有可识别的图片文件');
      return;
    }

    setIsRecognizing(true);
    try {
      // 对每个图片文件进行OCR识别
      const recognitionResults = await Promise.all(
        imageFiles.map(async (file) => {
          const result = await recognizeImageWithBaiduOCR(file);
          return result;
        })
      );

      // 合并所有识别结果
      const successfulResults = recognitionResults.filter(result => result.success);
      if (successfulResults.length > 0) {
        const combinedText = successfulResults
          .map(result => result.text)
          .join('\n\n');
        
        setSelectedRecord({
          ...record,
          recognizedText: combinedText
        });
      } else {
        const errorMessages = recognitionResults
          .filter(result => !result.success)
          .map(result => result.error)
          .join('\n');
        alert(`图片识别失败：\n${errorMessages}`);
      }
    } catch (error) {
      console.error('图片识别失败:', error);
      alert('图片识别失败，请稍后重试');
    } finally {
      setIsRecognizing(false);
    }
  };

  // 添加示范病历
  React.useEffect(() => {
    const addDemoRecords = async () => {
      const existingRecords = await getMedicalRecords();
      const hasDemoRecords = existingRecords.some(record => record.isDemo);
      
      if (!hasDemoRecords) {
        const demoRecords = [
          {
            id: 'demo-1',
            title: '2024年体检报告',
            content: '体检结果：血压正常 120/80mmHg，血糖正常 5.2mmol/L，心电图正常，肝功能正常。建议：保持良好生活习惯，定期复查。',
            type: 'uploaded',
            timestamp: new Date('2025-10-25T17:22:04').toISOString(),
            isDemo: true
          },
          {
            id: 'demo-2',
            title: '感冒就诊记录',
            content: '症状：发热、咳嗽、鼻塞。诊断：普通感冒。建议：多休息，多喝水，按时服药。',
            type: 'consultation',
            timestamp: new Date('2025-11-15T09:30:00').toISOString(),
            isDemo: true
          }
        ];
        
        for (const record of demoRecords) {
          await addMedicalRecord(record);
        }
        
        queryClient.invalidateQueries({ queryKey: ['medicalRecords'] });
      }
    };
    
    addDemoRecords();
  }, [queryClient]);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={() => navigate('/')}
                className="flex items-center text-gray-600 hover:text-gray-800 mr-4"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                返回首页
              </button>
              <h1 className="text-2xl font-bold text-gray-800">病历管理</h1>
            </div>
            <button
              onClick={() => setShowUpload(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              添加记录
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white rounded-lg shadow-md">
            <div className="border-b">
              <div className="flex">
                <button
                  onClick={() => setActiveTab('history')}
                  className={`px-6 py-4 text-sm font-medium ${
                    activeTab === 'history'
                      ? 'border-b-2 border-blue-500 text-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  问诊历史
                </button>
                <button
                  onClick={() => setActiveTab('uploaded')}
                  className={`px-6 py-4 text-sm font-medium ${
                    activeTab === 'uploaded'
                      ? 'border-b-2 border-blue-500 text-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  上传病历
                </button>
              </div>
            </div>

            <div className="p-6">
              {isLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-2 text-gray-600">加载中...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {records && records.filter(record => 
                    activeTab === 'history' ? record.type === 'consultation' : record.type === 'uploaded'
                  ).map((record) => (
                    <div key={record.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center mb-2">
                            {record.type === 'consultation' ? (
                              <FileText className="w-4 h-4 text-blue-600 mr-2" />
                            ) : (
                              <Image className="w-4 h-4 text-green-600 mr-2" />
                            )}
                            <h3 className="font-medium text-gray-800">
                              {record.title || '问诊记录'}
                              {record.isDemo && (
                                <span className="ml-2 px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">
                                  示范病例，仅供参考
                                </span>
                              )}
                            </h3>
                          </div>
                          <p className="text-gray-600 text-sm mb-2">{record.content}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(record.timestamp).toLocaleString()}
                          </p>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleViewDetail(record)}
                            className="text-blue-500 hover:text-blue-700 p-2"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          {record.files && record.files.length > 0 && (
                            <button
                              onClick={() => handleImageRecognition(record)}
                              disabled={isRecognizing}
                              className="text-green-500 hover:text-green-700 p-2 disabled:opacity-50"
                            >
                              <Scan className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteRecord(record.id)}
                            className="text-red-500 hover:text-red-700 p-2"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showUpload && (
        <RecordUpload
          onClose={() => setShowUpload(false)}
          onSuccess={() => {
            setShowUpload(false);
            queryClient.invalidateQueries({ queryKey: ['medicalRecords'] });
          }}
        />
      )}

      {/* 详情对话框 */}
      {showDetailDialog && selectedRecord && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-800">{selectedRecord.title}</h2>
              <button
                onClick={() => setShowDetailDialog(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-700 mb-2">内容摘要</h3>
                <p className="text-gray-600">{selectedRecord.content}</p>
              </div>
              {selectedRecord.recognizedText && (
                <div>
                  <h3 className="font-semibold text-gray-700 mb-2">图片识别结果</h3>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-gray-600 whitespace-pre-wrap">{selectedRecord.recognizedText}</p>
                  </div>
                </div>
              )}
              {selectedRecord.originalContent && (
                <div>
                  <h3 className="font-semibold text-gray-700 mb-2">详细内容</h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-gray-600 whitespace-pre-wrap">{selectedRecord.originalContent}</p>
                  </div>
                </div>
              )}
              {selectedRecord.files && selectedRecord.files.length > 0 && (
                <div>
                  <h3 className="font-semibold text-gray-700 mb-2">附件</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {selectedRecord.files.map((file, index) => (
                      <div key={index} className="border rounded-lg p-2">
                        {file.type && file.type.startsWith('image/') ? (
                          <div className="relative">
                            <img
                              src={URL.createObjectURL(file)}
                              alt={`附件 ${index + 1}`}
                              className="w-full h-32 object-cover rounded cursor-pointer"
                              onClick={() => handleViewImage(URL.createObjectURL(file))}
                            />
                            <button
                              onClick={() => handleViewImage(URL.createObjectURL(file))}
                              className="absolute top-2 right-2 bg-black bg-opacity-50 text-white p-1 rounded"
                            >
                              <ZoomIn className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center p-2">
                            <FileText className="w-8 h-8 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-600">{file.name}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div className="text-sm text-gray-500">
                <p>创建时间: {new Date(selectedRecord.timestamp).toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 图片查看对话框 */}
      {showImageDialog && selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="relative max-w-4xl max-h-[90vh]">
            <button
              onClick={() => setShowImageDialog(false)}
              className="absolute top-4 right-4 bg-black bg-opacity-50 text-white p-2 rounded-full z-10"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={selectedImage}
              alt="查看图片"
              className="max-w-full max-h-full object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default MedicalRecordPage;
