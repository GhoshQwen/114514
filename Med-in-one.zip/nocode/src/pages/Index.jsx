import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Stethoscope, FileText, MapPin, ArrowRight } from 'lucide-react';

const Index = () => {
  const navigate = useNavigate();

  const features = [
  {
    icon: <Stethoscope className="w-12 h-12 text-blue-600" />,
    title: "智能问诊",
    description: "AI专家为您提供专业的医疗咨询和建议",
    path: "/consultation"
  },
  {
    icon: <FileText className="w-12 h-12 text-green-600" />,
    title: "病历管理",
    description: "管理您的问诊历史和医疗记录",
    path: "/medical-record"
  },
  {
    icon: <MapPin className="w-12 h-12 text-purple-600" />,
    title: "人体部位诊断",
    description: "通过人体图快速定位症状部位",
    path: "/body-map"
  }];


  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-16">
          <h1 className="text-5xl text-gray-800 mb-2 font-extrabold">Med-In-One💊

          </h1>
          <p className="text-xl italic text-slate-600">家庭医生AI专家服务

          </p>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto mt-6">
            专业的AI医疗助手，为您提供慢性病管理、常见病咨询和急性症状响应服务
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {features.map((feature, index) =>
          <div
            key={index}
            className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow cursor-pointer"
            onClick={() => navigate(feature.path)}>

              <div className="flex flex-col items-center text-center">
                <div className="mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">
                  {feature.title}
                </h3>
                <p className="text-gray-600 mb-6">
                  {feature.description}
                </p>
                <div className="flex items-center text-blue-600 font-medium">
                  立即体验
                  <ArrowRight className="w-4 h-4 ml-2" />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">
              服务特色
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="text-left">
                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                  多模型集成
                </h3>
                <p className="text-gray-600">
                  集成多个专业AI模型，提供全面的医疗咨询服务
                </p>
              </div>
              <div className="text-left">
                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                  个性化服务
                </h3>
                <p className="text-gray-600">
                  基于您的病历和症状，提供个性化的医疗建议
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>);

};

export default Index;
