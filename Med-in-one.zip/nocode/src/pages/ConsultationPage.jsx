import { useQuery, useMutation } from '@tanstack/react-query';
import { getMedicalRecords, addMedicalRecord } from '../utils/medicalRecordUtils';
import { Heart, ThumbsUp, Bot, User, RotateCcw, Scan, Upload, FileText, ArrowLeft, ThumbsDown, Send } from 'lucide-react';
import ChatMessage from '../components/ChatMessage';
import { recognizeImageWithBaiduOCR } from '../utils/ocrService';
import React, { useRef, useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import ModelSelector from '../components/ModelSelector';

const ConsultationPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isMultiRoundMode, setIsMultiRoundMode] = useState(false);
  const [multiRoundInputs, setMultiRoundInputs] = useState([]);
  const [showSatisfactionDialog, setShowSatisfactionDialog] = useState(false);
  const [selectedMessageId, setSelectedMessageId] = useState(null);
  const [showFeedbackDialog, setShowFeedbackDialog] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [selectedModel, setSelectedModel] = useState('huatuo');
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [isRecognizing, setIsRecognizing] = useState(false);
  const [showMentalHealthReminder, setShowMentalHealthReminder] = useState(false);
  const [satisfactionMessageId, setSatisfactionMessageId] = useState(null);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  const { data: medicalRecords } = useQuery({
    queryKey: ['medicalRecords'],
    queryFn: getMedicalRecords,
  });

  // 处理从人体图页面传递的输入内容
  useEffect(() => {
    if (location.state && location.state.inputText) {
      setInputMessage(location.state.inputText);
    }
  }, [location.state]);

  // 自动滚动到最新消息
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 检查是否需要显示心理健康提醒
  useEffect(() => {
    const hasPhysicalSymptoms = messages.some(msg => 
      msg.sender === 'user' && 
      typeof msg.content === 'string' &&
      (msg.content.includes('疼痛') || msg.content.includes('不舒服') || msg.content.includes('难受') || 
       msg.content.includes('头痛') || msg.content.includes('胃痛') || msg.content.includes('失眠'))
    );
    
    if (hasPhysicalSymptoms && !showMentalHealthReminder) {
      setShowMentalHealthReminder(true);
      const reminderMessage = {
        id: Date.now(),
        content: "温馨提示：许多生理问题也可能与心理因素有关，如压力、焦虑等。建议您关注自身心理健康，适当放松心情，保持良好的作息习惯。",
        sender: 'ai',
        model: 'system',
        timestamp: new Date(),
        isReminder: true
      };
      setMessages(prev => [...prev, reminderMessage]);
    }
  }, [messages, showMentalHealthReminder]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() && selectedFiles.length === 0) return;

    let messageContent = inputMessage;
    
    // 如果有选中的文件，先进行OCR识别
    if (selectedFiles.length > 0) {
      setIsRecognizing(true);
      try {
        const recognitionResults = await Promise.all(
          selectedFiles.map(async (file) => {
            const result = await recognizeImageWithBaiduOCR(file);
            return result;
          })
        );

        const successfulResults = recognitionResults.filter(result => result && result.success);
        if (successfulResults.length > 0) {
          const recognizedText = successfulResults
            .map(result => result.text || '')
            .join('\n\n');
          
          // 将识别结果与用户输入结合
          messageContent = inputMessage 
            ? `${inputMessage}\n\n[图片识别结果]:\n${recognizedText}`
            : `[图片识别结果]:\n${recognizedText}`;
        } else {
          const errorMessages = recognitionResults
            .filter(result => result && !result.success)
            .map(result => result.error || '识别失败')
            .join('\n');
          throw new Error(`图片识别失败：\n${errorMessages}`);
        }
      } catch (error) {
        console.error('图片识别失败:', error);
        const errorMessage = {
          id: Date.now(),
          content: `图片识别失败: ${error.message || '未知错误'}`,
          sender: 'ai',
          model: selectedModel,
          timestamp: new Date(),
          isError: true,
        };
        setMessages(prev => [...prev, errorMessage]);
        setIsRecognizing(false);
        return;
      } finally {
        setIsRecognizing(false);
      }
    }

    const userMessage = {
      id: Date.now(),
      content: messageContent,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    
    if (isMultiRoundMode) {
      setMultiRoundInputs(prev => [...prev, messageContent]);
      setInputMessage('');
      setSelectedFiles([]);
      
      // 在多轮模式下，AI不会立即回复，而是提示用户继续描述
      const promptMessage = {
        id: Date.now() + 1,
        content: "您还有其他不适症状吗？请继续描述，这将帮助我更准确地判断。",
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, promptMessage]);
      return;
    }

    setInputMessage('');
    setSelectedFiles([]);
    setIsLoading(true);

    try {
      let aiResponse = '';
      
      // 只使用华佗GPT API，不再与ChatGPT API集成
      const response = await fetch('https://www.wisemodel.cn/apiserving/GhoshQwen/ldzwfzwr/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer wisemodel-ngfcrviiqapjubqpyejt'
        },
        body: JSON.stringify({
          model: "huatuo",
          messages: [{
            role: "user",
            content: messageContent
          }],
          temperature: 0.7,
          max_tokens: 1000,
          stream: false
        }),
      });

      if (!response.ok) {
        throw new Error('华佗GPT API请求失败');
      }

      const data = await response.json();
      aiResponse = data.choices && data.choices[0] && data.choices[0].message 
        ? data.choices[0].message.content || '抱歉，服务暂时不可用，请稍后重试。'
        : '抱歉，服务暂时不可用，请稍后重试。';

      const aiMessage = {
        id: Date.now() + 1,
        content: aiResponse,
        sender: 'ai',
        model: selectedModel,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, aiMessage]);

      // 检查AI回复是否包含疾病判断
      if (typeof aiResponse === 'string' && (aiResponse.includes('可能患有') || aiResponse.includes('疾病') || aiResponse.includes('症状'))) {
        setSatisfactionMessageId(aiMessage.id);
      }
    } catch (error) {
      console.error('问诊请求失败:', error);
      const errorMessage = {
        id: Date.now() + 1,
        content: '抱歉，服务暂时不可用，请稍后重试。',
        sender: 'ai',
        model: selectedModel,
        timestamp: new Date(),
        isError: true,
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateReport = async () => {
    if (multiRoundInputs.length === 0) return;
    
    setIsLoading(true);
    
    try {
      // 合并所有输入内容
      const combinedInput = multiRoundInputs.join(' ');
      
      let aiResponse = '';
      
      // 只使用华佗GPT API
      const response = await fetch('https://www.wisemodel.cn/apiserving/GhoshQwen/ldzwfzwr/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer wisemodel-ngfcrviiqapjubqpyejt'
        },
        body: JSON.stringify({
          model: "huatuo",
          messages: [{
            role: "user",
            content: `基于以下症状描述，请生成一个综合的诊断报告：${combinedInput}`
          }],
          temperature: 0.7,
          max_tokens: 1000,
          stream: false
        }),
      });

      if (!response.ok) {
        throw new Error('华佗GPT API请求失败');
      }

      const data = await response.json();
      aiResponse = data.choices && data.choices[0] && data.choices[0].message 
        ? data.choices[0].message.content || '抱歉，服务暂时不可用，请稍后重试。'
        : '抱歉，服务暂时不可用，请稍后重试。';

      const aiMessage = {
        id: Date.now() + 1,
        content: aiResponse,
        sender: 'ai',
        model: selectedModel,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, aiMessage]);
      setMultiRoundInputs([]);

      // 检查AI回复是否包含疾病判断
      if (typeof aiResponse === 'string' && (aiResponse.includes('可能患有') || aiResponse.includes('疾病') || aiResponse.includes('症状'))) {
        setSatisfactionMessageId(aiMessage.id);
      }
    } catch (error) {
      console.error('生成报告失败:', error);
      const errorMessage = {
        id: Date.now() + 1,
        content: '抱歉，生成报告失败，请稍后重试。',
        sender: 'ai',
        model: selectedModel,
        timestamp: new Date(),
        isError: true,
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSatisfactionResponse = (isSatisfied) => {
    setSatisfactionMessageId(null);
    
    if (isSatisfied) {
      // 用户满意，显示感谢信息
      const thankYouMessage = {
        id: Date.now(),
        content: "您的满意就是我们最大的动力！感谢您的支持。",
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, thankYouMessage]);
    } else {
      // 用户不满意，显示反馈对话框
      setShowFeedbackDialog(true);
    }
    
    // 保存问诊记录到病历管理
    saveConsultationRecord();
  };

  const handleFeedbackSubmit = () => {
    if (!feedbackText.trim()) return;
    
    // 这里应该调用API将反馈提交给管理员
    console.log('用户反馈:', feedbackText);
    
    setShowFeedbackDialog(false);
    setFeedbackText('');
    
    // 显示感谢信息
    const thankYouMessage = {
      id: Date.now(),
      content: "感谢您的反馈，我们会不断改进服务质量。",
      sender: 'ai',
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, thankYouMessage]);
  };

  const saveConsultationRecord = async () => {
    const selectedMessage = messages.find(msg => msg.id === satisfactionMessageId);
    if (!selectedMessage || typeof selectedMessage.content !== 'string') return;
    
    try {
      // 使用AI生成总结和标题
      let summaryText = '';
      
      // 只使用华佗GPT API
      const summaryResponse = await fetch('https://www.wisemodel.cn/apiserving/GhoshQwen/ldzwfzwr/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer wisemodel-ngfcrviiqapjubqpyejt'
        },
        body: JSON.stringify({
          model: "huatuo",
          messages: [{
            role: "user",
            content: `请用100字以内总结以下内容，并生成一个简短的标题：${selectedMessage.content}`
          }],
          temperature: 0.7,
          max_tokens: 200,
          stream: false
        }),
      });

      if (!summaryResponse.ok) {
        throw new Error('生成总结失败');
      }

      const summaryData = await summaryResponse.json();
      summaryText = summaryData.choices && summaryData.choices[0] && summaryData.choices[0].message 
        ? summaryData.choices[0].message.content || ''
        : '';
      
      // 提取标题和总结
      const titleMatch = summaryText.match(/标题[:：]\s*(.+)/);
      const title = titleMatch ? titleMatch[1].trim() : '问诊记录';
      const summary = summaryText.replace(/标题[:：]\s*.+/, '').trim();

      // 保存到病历管理
      await addMedicalRecord({
        title: title,
        content: summary,
        type: 'consultation',
        originalContent: selectedMessage.content
      });
    } catch (error) {
      console.error('保存问诊记录失败:', error);
    }
  };

  const toggleMode = () => {
    setIsMultiRoundMode(!isMultiRoundMode);
    setMultiRoundInputs([]);
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setSelectedFiles(files);
  };

  const handleImageRecognition = async () => {
    if (selectedFiles.length === 0) {
      alert('请先选择图片文件');
      return;
    }

    setIsRecognizing(true);
    try {
      const recognitionResults = await Promise.all(
        selectedFiles.map(async (file) => {
          const result = await recognizeImageWithBaiduOCR(file);
          return result;
        })
      );

      const successfulResults = recognitionResults.filter(result => result && result.success);
      if (successfulResults.length > 0) {
        const recognizedText = successfulResults
          .map(result => result.text || '')
          .join('\n\n');
        
        setInputMessage(recognizedText);
      } else {
        const errorMessages = recognitionResults
          .filter(result => result && !result.success)
          .map(result => result.error || '识别失败')
          .join('\n');
        alert(`图片识别失败：\n${errorMessages}`);
      }
    } catch (error) {
      console.error('图片识别失败:', error);
      alert('图片识别失败，请稍后重试');
    } finally {
      setIsRecognizing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={() => navigate('/')}
                className="flex items-center text-gray-600 hover:text-gray-800 mr-4"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                返回首页
              </button>
              <h1 className="text-2xl font-bold text-gray-800">智能问诊</h1>
            </div>
            <div className="flex items-center space-x-4">
              <ModelSelector 
                selectedModel={selectedModel} 
                onModelChange={setSelectedModel} 
              />
              <button
                onClick={toggleMode}
                className={`flex items-center px-4 py-2 rounded-lg ${
                  isMultiRoundMode 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                {isMultiRoundMode ? '多轮模式' : '正常模式'}
              </button>
              {isMultiRoundMode && (
                <button
                  onClick={handleGenerateReport}
                  disabled={multiRoundInputs.length === 0 || isLoading}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  生成诊断报告
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md h-96 overflow-y-auto mb-4 p-4">
            {messages.length === 0 ? (
              <div className="text-center text-gray-500 mt-20">
                <Bot className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p>您好！我是您的AI医疗助手，请描述您的症状或健康问题。</p>
              </div>
            ) : (
              messages.map((message) => (
                <div key={message.id} className="mb-4">
                  <ChatMessage message={message} />
                  {/* 在AI回复下方显示满意度调查 */}
                  {satisfactionMessageId === message.id && (
                    <div className="flex justify-center mt-2">
                      <div className="bg-white border rounded-lg p-3 shadow-md">
                        <p className="text-sm text-gray-600 mb-2">您对这个问诊结果满意吗？</p>
                        <div className="flex justify-center space-x-3">
                          <button
                            onClick={() => handleSatisfactionResponse(true)}
                            className="flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 text-sm"
                          >
                            <ThumbsUp className="w-4 h-4 mr-1" />
                            满意
                          </button>
                          <button
                            onClick={() => handleSatisfactionResponse(false)}
                            className="flex items-center px-3 py-1 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 text-sm"
                          >
                            <ThumbsDown className="w-4 h-4 mr-1" />
                            不满意
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="flex gap-4">
            <div className="flex-1">
              <div className="flex gap-2 mb-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  multiple
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  上传图片
                </button>
                {selectedFiles.length > 0 && (
                  <button
                    onClick={handleImageRecognition}
                    disabled={isRecognizing}
                    className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center"
                  >
                    <Scan className="w-4 h-4 mr-2" />
                    {isRecognizing ? '识别中...' : '识别图片'}
                  </button>
                )}
              </div>
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="请描述您的症状或健康问题..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={isLoading || isRecognizing}
              />
              {selectedFiles.length > 0 && (
                <div className="mt-2 text-sm text-gray-600">
                  已选择 {selectedFiles.length} 个文件
                </div>
              )}
            </div>
            <button
              onClick={handleSendMessage}
              disabled={isLoading || isRecognizing || (!inputMessage.trim() && selectedFiles.length === 0)}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              <Send className="w-5 h-5 mr-2" />
              发送
            </button>
          </div>
        </div>
      </div>

      {/* 反馈对话框 */}
      {showFeedbackDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">请告诉我们您遇到的问题</h3>
            <textarea
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="请详细描述您遇到的问题或不满意的地方..."
            />
            <div className="flex justify-end space-x-3 mt-4">
              <button
                onClick={() => setShowFeedbackDialog(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                取消
              </button>
              <button
                onClick={handleFeedbackSubmit}
                disabled={!feedbackText.trim()}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                提交反馈
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConsultationPage;
