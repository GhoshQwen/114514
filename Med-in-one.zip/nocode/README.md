# 家庭医生AI专家服务

这是一个基于React和Vite构建的家庭医生AI专家服务应用。该应用提供了智能问诊、病历管理和人体部位诊断等功能。

## 功能特性

- **智能问诊**：AI专家为您提供专业的医疗咨询和建议
- **病历管理**：管理您的问诊历史和医疗记录
- **人体部位诊断**：通过人体图快速定位症状部位
- **满意度调查**：对AI诊断结果进行满意度评价
- **智能概括**：自动生成病历摘要和标题

## 技术栈

- React 18
- Vite
- Tailwind CSS
- React Router
- TanStack Query
- Lucide React

## 安装与运行

1. 克隆项目
2. 安装依赖：`npm install`
3. 启动开发服务器：`npm run dev`
4. 构建生产版本：`npm run build`

## 项目结构

- `src/pages`：页面组件
- `src/components`：可复用组件
- `src/utils`：工具函数
- `src/lib`：第三方库封装

## 许可证

MIT
